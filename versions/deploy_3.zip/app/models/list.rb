class List < ApplicationRecord
  has_many :items
end